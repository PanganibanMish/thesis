--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_type`
--

CREATE TABLE `attendance_type` (
  `id` int(11) NOT NULL,
  `attendance_name` text NOT NULL,
  `remarks` text NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance_type`
--

INSERT INTO `attendance_type` (`id`, `attendance_name`, `remarks`, `created_by`, `date_created`, `modified_by`, `date_modified`) VALUES
(1, 'Present', 'rrrrr', 0, '2020-03-02 23:26:22', 0, '2020-03-02 23:56:46'),
(2, 'Absent', 'aaaaaa', 0, '2020-03-02 23:58:42', 0, '0000-00-00 00:00:00'),
(3, 'Absent', 'asdddd', 0, '2020-03-03 00:17:48', 0, '0000-00-00 00:00:00'),
(4, 'Excused', 'Fever', 0, '2020-03-03 00:24:49', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `id` bigint(20) NOT NULL,
  `student_id` int(11) NOT NULL,
  `school_year` year(4) NOT NULL,
  `grade_level_id` bigint(20) NOT NULL,
  `section_level_id` bigint(20) NOT NULL,
  `remarks` text NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `grade_level`
--

CREATE TABLE `grade_level` (
  `grade_level_id` int(11) NOT NULL,
  `grade_level` text NOT NULL,
  `adviser` bigint(20) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grade_level`
--

INSERT INTO `grade_level` (`grade_level_id`, `grade_level`, `adviser`, `created_by`, `date_created`, `modified_by`, `date_modified`) VALUES
(5, 'Grade 12', 2, 1, '2020-03-01 13:55:32', 1, '2020-03-01 16:19:06'),
(6, '2', 2, 1, '2020-03-01 14:40:25', 0, NULL),
(7, 'Grade 5', 1, 1, '2020-03-01 14:41:46', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `registrar_announcement`
--

CREATE TABLE `registrar_announcement` (
  `id` bigint(20) NOT NULL,
  `announcement_name` text NOT NULL,
  `announcement_details` text NOT NULL,
  `date` date NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedule_id` bigint(20) NOT NULL,
  `school_year` year(4) NOT NULL,
  `schedule_name` text NOT NULL,
  `grade_level_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `day` text NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `teacher` bigint(20) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedule_id`, `school_year`, `schedule_name`, `grade_level_id`, `subject_id`, `section_id`, `day`, `time_start`, `time_end`, `teacher`, `created_by`, `date_created`, `modified_by`, `date_modified`) VALUES
(1, 2002, 'wwwwwwww', 1, 3, 2, 'rrrrrrrr', '04:00:00', '05:00:00', 3, 0, '2020-03-07 13:40:50', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` bigint(20) NOT NULL,
  `section_name` varchar(11) NOT NULL,
  `grade_level` int(11) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section_name`, `grade_level`, `created_by`, `date_created`, `modified_by`, `date_modified`) VALUES
(2, 'ffffffff', 2, 0, '2020-02-28 16:51:44', 0, '0000-00-00 00:00:00'),
(3, 'St.Boscon', 5, 0, '2020-03-01 15:07:16', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `id` bigint(20) NOT NULL,
  `grade_level` bigint(20) NOT NULL,
  `schedule_id` bigint(20) NOT NULL,
  `attendance_date` date NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_grades`
--

CREATE TABLE `student_grades` (
  `grade_id` bigint(20) NOT NULL,
  `schedule_id` bigint(20) NOT NULL,
  `grade` float NOT NULL,
  `remarks` text NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_parent`
--

CREATE TABLE `student_parent` (
  `parent_id` bigint(20) NOT NULL,
  `parent_type` text NOT NULL,
  `student_id` bigint(20) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `middle_name` text NOT NULL,
  `birthday` date NOT NULL,
  `birth_place` text NOT NULL,
  `current_address` text NOT NULL,
  `mobile_no` text NOT NULL,
  `highest_education` text NOT NULL,
  `occupation` text NOT NULL,
  `employer` text NOT NULL,
  `work_place` text NOT NULL,
  `monthly_income` float NOT NULL,
  `annual_income` float NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_profile`
--

CREATE TABLE `student_profile` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(10) NOT NULL,
  `birthday` date NOT NULL,
  `contact_no` text NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `religion` text NOT NULL,
  `home_address` varchar(250) NOT NULL,
  `zip_code` text NOT NULL,
  `gender` text NOT NULL,
  `nationality` text NOT NULL,
  `place_of_birth` varchar(250) NOT NULL,
  `mother_tongue` text NOT NULL,
  `recent_school_attended` text NOT NULL,
  `parent_status` varchar(25) NOT NULL,
  `student_living_with` text NOT NULL,
  `other_relative` text NOT NULL,
  `guardian_same` tinyint(1) NOT NULL,
  `number_of_siblings_in_institution` int(11) NOT NULL,
  `study_supporter` text NOT NULL,
  `relationship` text NOT NULL,
  `occupation` text NOT NULL,
  `address` text NOT NULL,
  `guardian_name` text NOT NULL,
  `guardian_relationship` text NOT NULL,
  `guardian_bday` date NOT NULL,
  `guardian_birth_place` text NOT NULL,
  `guardian_address` text NOT NULL,
  `guardian_mobile` text NOT NULL,
  `guardian_education` text NOT NULL,
  `guardian_occupation` text NOT NULL,
  `guardian_employer` text NOT NULL,
  `guardian_employer_address` text NOT NULL,
  `guardian_monthly_income` float NOT NULL,
  `guardian_annual_income` float NOT NULL,
  `status` text NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` bigint(20) NOT NULL,
  `subject_code` text NOT NULL,
  `subject_name` text NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_code`, `subject_name`, `created_by`, `date_created`, `modified_by`, `date_modified`) VALUES
(1, 'asd', 'sdsada', 0, '2020-02-28 16:53:18', 0, '0000-00-00 00:00:00'),
(2, 'aMath', 'Mathematics', 0, '2020-03-01 15:07:58', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_announcement`
--

CREATE TABLE `teacher_announcement` (
  `announcement_id` bigint(20) NOT NULL,
  `student_id` bigint(20) NOT NULL,
  `details` text NOT NULL,
  `target_date` date NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `remarks` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `approved_by` bigint(20) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `date_modified` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_list`
--

CREATE TABLE `user_list` (
  `user_id` bigint(20) NOT NULL,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `user_type` int(11) NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_no` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `login_first` tinyint(1) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) NOT NULL,
  `modified_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_list`
--

INSERT INTO `user_list` (`user_id`, `first_name`, `last_name`, `middle_name`, `status`, `user_type`, `birthday`, `email`, `contact_no`, `username`, `password`, `login_first`, `created_by`, `date_created`, `modified_by`, `modified_date`) VALUES
(1, 'Michelle', 'Panganiban', '', 1, 0, '1997-10-30', 'michellepanganiban29@gmail.com', '09128515548', 'panganibanmish', '827ccb0eea8a706c4c34a16891f84e7b', 0, 0, '2020-02-26 22:53:41', 1, '0000-00-00 00:00:00'),
(2, 'ssdfsd', 'asd', '', 0, 2, '2020-02-27', '', 'asd', 'ssds', '', 0, 0, '2020-02-26 23:19:36', 0, '0000-00-00 00:00:00'),
(4, 'Michelle', 'Panganiban', '', 0, 0, '1997-10-30', 'panganibanmish@gmail.com', '09128515548', 'panganibanmish', ' 21232f297a57a5a743894a0e4a801fc3', 0, 0, '2020-03-01 14:49:45', 0, '0000-00-00 00:00:00'),
(5, 'Kristine ', 'Samson', '', 0, 5, '2020-03-04', 'kristinejoysamsong@yahoo.com', '09123456789', 'tin', '', 0, 0, '2020-03-02 14:17:03', 0, '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_type`
--
ALTER TABLE `attendance_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grade_level`
--
ALTER TABLE `grade_level`
  ADD PRIMARY KEY (`grade_level_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `student_parent`
--
ALTER TABLE `student_parent`
  ADD PRIMARY KEY (`parent_id`);

--
-- Indexes for table `student_profile`
--
ALTER TABLE `student_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `user_list`
--
ALTER TABLE `user_list`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance_type`
--
ALTER TABLE `attendance_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `enrollment`
--
ALTER TABLE `enrollment`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `grade_level`
--
ALTER TABLE `grade_level`
  MODIFY `grade_level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `schedule_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `grade_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student_parent`
--
ALTER TABLE `student_parent`
  MODIFY `parent_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student_profile`
--
ALTER TABLE `student_profile`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user_list`
--
ALTER TABLE `user_list`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
